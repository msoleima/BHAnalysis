import FWCore.ParameterSet.Config as cms

demo = cms.EDAnalyzer('BHAnalyzerTLBSM'
)
